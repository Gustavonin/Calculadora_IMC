package com.example.fluttercreatecalculadoraimc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
